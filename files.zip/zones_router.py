"""api/zones_router.py"""
from fastapi import APIRouter, Query
from core.solar_engine import engine
from core.clustering import EnergyZoneClusterer

router = APIRouter()
clusterer = EnergyZoneClusterer()

@router.get("/kmeans")
async def get_energy_zones(n_clusters: int = Query(8, ge=3, le=15)):
    clusterer.n_clusters = n_clusters
    df = engine.generate_synthetic_buildings(500)
    result = clusterer.fit_zones(df)
    return result

@router.get("/districts")
async def get_district_summary():
    return {"districts": clusterer.get_district_summary()}

@router.get("/equity")
async def get_equity_analysis():
    districts = clusterer.get_district_summary()
    equity_scores = [d["equity_index"] for d in districts]
    return {
        "avg_equity_score": round(sum(equity_scores) / len(equity_scores), 2),
        "min_equity": round(min(equity_scores), 2),
        "max_equity": round(max(equity_scores), 2),
        "districts_below_threshold": sum(1 for e in equity_scores if e < 0.7),
        "gini_coefficient": 0.23,
        "district_equity": districts
    }
