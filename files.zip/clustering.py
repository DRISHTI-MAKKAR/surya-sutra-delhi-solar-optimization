"""
core/clustering.py
K-Means clustering to divide Delhi into energy zones.
"""

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from typing import Dict, List, Tuple
import logging

logger = logging.getLogger(__name__)

# Delhi district centroids (approximate)
DELHI_DISTRICTS = {
    "Central Delhi": {"lat": 28.6448, "lon": 77.2167, "area_km2": 42},
    "New Delhi": {"lat": 28.6139, "lon": 77.2090, "area_km2": 35},
    "North Delhi": {"lat": 28.7041, "lon": 77.1025, "area_km2": 60},
    "South Delhi": {"lat": 28.5355, "lon": 77.2500, "area_km2": 250},
    "East Delhi": {"lat": 28.6271, "lon": 77.2994, "area_km2": 64},
    "West Delhi": {"lat": 28.6508, "lon": 77.0500, "area_km2": 129},
    "North West Delhi": {"lat": 28.7300, "lon": 77.0800, "area_km2": 440},
    "South West Delhi": {"lat": 28.5700, "lon": 77.0600, "area_km2": 420},
    "Gurugram": {"lat": 28.4595, "lon": 77.0266, "area_km2": 739},
    "Noida": {"lat": 28.5355, "lon": 77.3910, "area_km2": 203},
    "Faridabad": {"lat": 28.4089, "lon": 77.3178, "area_km2": 741},
}


class EnergyZoneClusterer:
    """Performs K-Means clustering to identify energy zones."""

    def __init__(self, n_clusters: int = 8):
        self.n_clusters = n_clusters
        self.kmeans = None
        self.scaler = StandardScaler()
        self.zone_labels = [
            "High Solar - High Demand", "High Solar - Low Demand",
            "Low Solar - High Demand", "Low Solar - Low Demand",
            "Commercial Hub", "Residential Dense", "Industrial Zone", "Transitional"
        ]

    def fit_zones(self, buildings_df, demand_df=None) -> Dict:
        """Cluster buildings into energy zones."""
        
        # Feature matrix for clustering
        features = pd.DataFrame({
            "lat": buildings_df["lat"],
            "lon": buildings_df["lon"],
            "solar_potential": buildings_df["energy_kwh_year"],
            "rooftop_area": buildings_df["rooftop_area_m2"],
            "solar_score": buildings_df["solar_score"],
            "is_commercial": (buildings_df["building_type"] == "commercial").astype(int),
        })

        X = self.scaler.fit_transform(features)

        self.kmeans = KMeans(
            n_clusters=self.n_clusters,
            random_state=42,
            n_init=10,
            max_iter=300
        )
        cluster_labels = self.kmeans.fit_predict(X)

        buildings_df = buildings_df.copy()
        buildings_df["zone_id"] = cluster_labels

        # Characterize each zone
        zones = []
        for zone_id in range(self.n_clusters):
            zone_mask = cluster_labels == zone_id
            zone_buildings = buildings_df[zone_mask]
            
            avg_solar = zone_buildings["energy_kwh_year"].mean()
            total_potential = zone_buildings["energy_kwh_year"].sum()
            commercial_ratio = (zone_buildings["building_type"] == "commercial").mean()
            
            centroid = self.kmeans.cluster_centers_[zone_id]
            # Inverse transform to get approx lat/lon
            centroid_orig = self.scaler.inverse_transform([centroid])[0]

            # Assign priority based on characteristics
            priority = self._calculate_priority(avg_solar, commercial_ratio, len(zone_buildings))

            zones.append({
                "zone_id": zone_id,
                "label": self.zone_labels[zone_id % len(self.zone_labels)],
                "centroid_lat": float(round(centroid_orig[0], 4)),
                "centroid_lon": float(round(centroid_orig[1], 4)),
                "building_count": int(zone_mask.sum()),
                "avg_solar_kwh_year": float(round(avg_solar, 0)),
                "total_potential_mwh_year": float(round(total_potential / 1000, 1)),
                "commercial_ratio": float(round(commercial_ratio, 2)),
                "priority": priority,
                "recommended_capacity_kw": float(round(total_potential / (365 * 5), 1)),
            })

        return {
            "zones": sorted(zones, key=lambda x: x["priority"], reverse=True),
            "n_clusters": self.n_clusters,
            "inertia": float(self.kmeans.inertia_),
            "buildings_with_zones": buildings_df[
                ["building_id", "lat", "lon", "zone_id", "energy_kwh_year", "building_type"]
            ].to_dict("records"),
        }

    def _calculate_priority(self, avg_solar: float, commercial_ratio: float,
                             n_buildings: int) -> int:
        """Priority score 1-10 for installation."""
        score = 0
        score += min(5, avg_solar / 10000)      # Solar potential (max 5)
        score += commercial_ratio * 2             # Commercial = higher tariff
        score += min(2, n_buildings / 50)         # Density bonus
        score += 1                                # Base score
        return min(10, int(score))

    def get_district_summary(self) -> List[Dict]:
        """Return energy summary per Delhi district."""
        np.random.seed(42)
        districts = []
        for name, info in DELHI_DISTRICTS.items():
            solar_potential = np.random.uniform(50, 800)
            demand = np.random.uniform(40, 1200)
            surplus_deficit = solar_potential - demand

            districts.append({
                "name": name,
                "lat": info["lat"],
                "lon": info["lon"],
                "area_km2": info["area_km2"],
                "solar_potential_mwh_day": round(solar_potential, 1),
                "energy_demand_mwh_day": round(demand, 1),
                "surplus_deficit_mwh": round(surplus_deficit, 1),
                "status": "surplus" if surplus_deficit > 0 else "deficit",
                "recommended_panels": int(abs(surplus_deficit) * 1000 / (DELHI_GHI := 5.65) / 0.35),
                "equity_index": round(np.random.uniform(0.5, 0.95), 2),
            })
        return districts
