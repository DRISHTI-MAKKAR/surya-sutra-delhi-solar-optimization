"""api/forecast_router.py"""
from fastapi import APIRouter, Query
from core.forecaster import DemandForecaster

router = APIRouter()
forecaster = DemandForecaster()

@router.get("/demand")
async def get_demand_forecast(years: int = Query(5, ge=1, le=10)):
    return forecaster.forecast_demand(years)

@router.get("/roi")
async def get_roi_projection(investment_cr: float = Query(50, description="Investment in Crore INR")):
    return forecaster.get_roi_projection(investment_cr)

@router.get("/monthly")
async def get_monthly_forecast():
    result = forecaster.forecast_demand(1)
    return {"monthly": result["monthly_forecast"]}
