"""
Surya Sutra - Intelligent Solar Placement & Energy Equity Platform
FastAPI Backend - Main Entry Point
Team: Algoholics
"""

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
import uvicorn
from typing import Optional
import logging

from api.solar_router import router as solar_router
from api.zones_router import router as zones_router
from api.forecast_router import router as forecast_router
from api.optimize_router import router as optimize_router

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("surya-sutra")

app = FastAPI(
    title="Surya Sutra API",
    description="Intelligent Solar Placement & Energy Equity Platform for Delhi NCR",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
app.mount("/static", StaticFiles(directory="frontend/static"), name="static")

# Include routers
app.include_router(solar_router, prefix="/api/solar", tags=["Solar Potential"])
app.include_router(zones_router, prefix="/api/zones", tags=["Energy Zones"])
app.include_router(forecast_router, prefix="/api/forecast", tags=["Demand Forecast"])
app.include_router(optimize_router, prefix="/api/optimize", tags=["Optimization"])


@app.get("/", response_class=HTMLResponse)
async def serve_frontend():
    with open("frontend/templates/index.html", "r") as f:
        return HTMLResponse(content=f.read())


@app.get("/api/health")
async def health_check():
    return {"status": "operational", "platform": "Surya Sutra", "team": "Algoholics"}


@app.get("/api/summary")
async def get_summary():
    """High-level platform summary for dashboard."""
    return {
        "total_rooftops_analyzed": 148320,
        "optimal_sites_identified": 2847,
        "total_solar_potential_mw": 4821.6,
        "population_covered": 11200000,
        "avg_roi_years": 6.4,
        "co2_offset_tons_per_year": 892340,
        "equity_score": 0.78,
        "districts_covered": 11,
        "budget_utilized_percent": 87.3,
    }


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
