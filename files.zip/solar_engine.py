"""
core/solar_engine.py
Core computation engine for solar potential analysis.
Simulates real dataset pipelines for Delhi NCR.
"""

import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point, Polygon, box
from typing import Tuple, List, Dict
import json
import logging

logger = logging.getLogger(__name__)

# Delhi NCR Bounding Box
DELHI_BOUNDS = {
    "min_lat": 28.40,
    "max_lat": 28.88,
    "min_lon": 76.84,
    "max_lon": 77.35,
}

# Real solar irradiance data for Delhi (kWh/m²/day) - monthly averages
DELHI_GHI_MONTHLY = {
    1: 4.2, 2: 5.1, 3: 6.3, 4: 7.1, 5: 7.4, 6: 6.2,
    7: 4.8, 8: 4.5, 9: 5.6, 10: 5.9, 11: 4.8, 12: 3.9
}
DELHI_GHI_ANNUAL = 5.65  # kWh/m²/day annual average

PANEL_EFFICIENCY = 0.185       # 18.5% - monocrystalline panels
PERFORMANCE_RATIO = 0.80       # System losses
PANEL_COST_PER_KW = 45000      # INR per kW installed
GRID_TRANSMISSION_COST = 2.5   # INR per kWh


class SolarEngine:
    """Main computation engine for solar placement optimization."""

    def __init__(self):
        self.delhi_bounds = DELHI_BOUNDS
        self.ghi_annual = DELHI_GHI_ANNUAL
        self.buildings_df = None
        self.demand_df = None

    def generate_synthetic_buildings(self, n: int = 500) -> gpd.GeoDataFrame:
        """
        Simulate building footprint data from OSM/Bhuvan.
        In production: load from PostGIS using geopandas.read_postgis()
        """
        np.random.seed(42)

        # Weighted spatial distribution (denser in central Delhi)
        lats = np.random.normal(28.65, 0.12, n)
        lons = np.random.normal(77.10, 0.14, n)

        lats = np.clip(lats, DELHI_BOUNDS["min_lat"], DELHI_BOUNDS["max_lat"])
        lons = np.clip(lons, DELHI_BOUNDS["min_lon"], DELHI_BOUNDS["max_lon"])

        # Building types with real-world proportions
        building_types = np.random.choice(
            ["residential", "commercial", "industrial", "institutional"],
            n, p=[0.65, 0.20, 0.08, 0.07]
        )

        # Rooftop areas in m² by type
        area_ranges = {
            "residential": (60, 250),
            "commercial": (200, 2000),
            "industrial": (500, 5000),
            "institutional": (300, 3000),
        }

        rooftop_areas = np.array([
            np.random.uniform(*area_ranges[bt]) for bt in building_types
        ])

        # Shadow/obstruction factor (0-1, higher = less shadow)
        shadow_factors = np.random.beta(5, 2, n)

        # Tilt optimization factor (roof pitch impact)
        tilt_factors = np.random.uniform(0.85, 1.0, n)

        # Local GHI with microclimate variation
        ghi_local = DELHI_GHI_ANNUAL * np.random.uniform(0.92, 1.08, n)

        # Energy potential calculation: E = A × GHI × η × PR × shadow × tilt
        energy_kwh_day = (
            rooftop_areas * ghi_local * PANEL_EFFICIENCY *
            PERFORMANCE_RATIO * shadow_factors * tilt_factors
        )
        energy_kwh_year = energy_kwh_day * 365

        # Installation cost (INR)
        capacity_kw = energy_kwh_day / (DELHI_GHI_ANNUAL * PERFORMANCE_RATIO)
        installation_cost = capacity_kw * PANEL_COST_PER_KW

        # CO2 offset (kg/year) - 0.82 kg CO2/kWh (India grid)
        co2_offset_kg_year = energy_kwh_year * 0.82

        # ROI years
        annual_savings = energy_kwh_year * 8.0  # INR 8/kWh avg tariff
        roi_years = np.where(annual_savings > 0, installation_cost / annual_savings, 99)

        gdf = gpd.GeoDataFrame({
            "building_id": [f"BLD_{i:05d}" for i in range(n)],
            "lat": lats,
            "lon": lons,
            "building_type": building_types,
            "rooftop_area_m2": rooftop_areas.round(1),
            "shadow_factor": shadow_factors.round(3),
            "tilt_factor": tilt_factors.round(3),
            "ghi_local": ghi_local.round(3),
            "energy_kwh_day": energy_kwh_day.round(2),
            "energy_kwh_year": energy_kwh_year.round(0),
            "capacity_kw": capacity_kw.round(2),
            "installation_cost_inr": installation_cost.round(0),
            "co2_offset_kg_year": co2_offset_kg_year.round(0),
            "roi_years": roi_years.round(1),
            "annual_savings_inr": annual_savings.round(0),
            "solar_score": (shadow_factors * tilt_factors * ghi_local / DELHI_GHI_ANNUAL).round(3),
        }, geometry=gpd.points_from_xy(lons, lats))

        gdf.set_crs(epsg=4326, inplace=True)
        self.buildings_df = gdf
        return gdf

    def compute_demand_grid(self, resolution: float = 0.01) -> pd.DataFrame:
        """
        Generate energy demand grid using population density + commercial proxy.
        In production: use WorldPop raster + VIIRS nighttime lights
        """
        np.random.seed(123)

        lats = np.arange(DELHI_BOUNDS["min_lat"], DELHI_BOUNDS["max_lat"], resolution)
        lons = np.arange(DELHI_BOUNDS["min_lon"], DELHI_BOUNDS["max_lon"], resolution)

        demand_records = []
        for lat in lats:
            for lon in lons:
                # Population density proxy (persons/km²)
                # Higher near center (Connaught Place ~77.22, 28.63)
                dist_center = np.sqrt((lat - 28.63)**2 + (lon - 77.22)**2)
                pop_density = max(0, 35000 * np.exp(-dist_center / 0.08) +
                                  np.random.normal(0, 1000))

                # Commercial intensity from VIIRS nighttime lights proxy
                commercial_intensity = (
                    0.7 * np.exp(-dist_center / 0.12) +
                    0.3 * np.random.beta(2, 5)
                )

                # Energy demand (kWh/day/cell)
                # Residential: 8 kWh/household/day, ~4 persons/household
                residential_demand = (pop_density * 0.0001) * (8.0 / 4) * (resolution * 111)**2
                commercial_demand = commercial_intensity * 500 * (resolution * 111)**2
                total_demand = residential_demand + commercial_demand

                demand_records.append({
                    "lat": round(lat, 4),
                    "lon": round(lon, 4),
                    "pop_density": round(pop_density, 0),
                    "commercial_intensity": round(commercial_intensity, 3),
                    "residential_demand_kwh": round(residential_demand, 2),
                    "commercial_demand_kwh": round(commercial_demand, 2),
                    "total_demand_kwh": round(total_demand, 2),
                })

        df = pd.DataFrame(demand_records)
        self.demand_df = df
        return df

    def calculate_energy_equation(self, rooftop_area: float, ghi: float = DELHI_GHI_ANNUAL,
                                   efficiency: float = PANEL_EFFICIENCY,
                                   shadow_factor: float = 0.9,
                                   tilt_factor: float = 0.95) -> Dict:
        """
        Core energy equation:
        E = A × GHI × η × PR × f_shadow × f_tilt
        """
        energy_day = rooftop_area * ghi * efficiency * PERFORMANCE_RATIO * shadow_factor * tilt_factor
        energy_year = energy_day * 365
        capacity = energy_day / (ghi * PERFORMANCE_RATIO)

        return {
            "energy_kwh_day": round(energy_day, 2),
            "energy_kwh_year": round(energy_year, 0),
            "capacity_kw": round(capacity, 2),
            "formula": f"E = {rooftop_area}m² × {ghi} × {efficiency} × {PERFORMANCE_RATIO} × {shadow_factor} × {tilt_factor}",
        }

    def get_heatmap_data(self, data_type: str = "solar", n_points: int = 300) -> List[Dict]:
        """Generate heatmap data for Leaflet.heat layer."""
        if self.buildings_df is None:
            self.generate_synthetic_buildings(n_points)

        df = self.buildings_df

        if data_type == "solar":
            # Normalize solar score for intensity
            max_val = df["energy_kwh_year"].max()
            points = [
                [row["lat"], row["lon"], float(row["energy_kwh_year"] / max_val)]
                for _, row in df.iterrows()
            ]
        elif data_type == "demand":
            demand_df = self.compute_demand_grid(resolution=0.015)
            max_val = demand_df["total_demand_kwh"].max()
            points = [
                [row["lat"], row["lon"], float(row["total_demand_kwh"] / max_val)]
                for _, row in demand_df.iterrows()
            ]
        else:
            points = []

        return points


# Singleton instance
engine = SolarEngine()
