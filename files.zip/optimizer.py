"""
core/optimizer.py
Solar placement optimization using linear programming.
Minimizes cost + unmet demand subject to budget/grid constraints.
"""

import numpy as np
import pandas as pd
from scipy.optimize import linprog, minimize
from typing import Dict, List, Tuple
import logging

logger = logging.getLogger(__name__)

# Optimization parameters
BUDGET_INR = 500_000_000      # INR 50 Crore total budget
GRID_CAPACITY_MW = 150        # Max grid injection capacity
PANEL_COST_PER_KW = 45_000    # INR/kW
UNMET_DEMAND_PENALTY = 50_000  # INR per MWh unmet (social cost)
MIN_EQUITY_SCORE = 0.70       # Ensure ≥70% zones get coverage


class SolarOptimizer:
    """
    Linear Programming Optimization Model:
    
    Variables: x_i = capacity installed at site i (kW)
    
    Objective:
        Minimize: Σ(cost_i × x_i) + Σ(penalty × max(0, demand_j - supply_j))
    
    Constraints:
        1. Σ(cost_i × x_i) ≤ Budget
        2. Σ(x_i) ≤ Grid_Capacity × 1000 (kW)
        3. x_i ≤ max_capacity_i (rooftop limit)
        4. x_i ≥ 0
        5. Coverage equity: min zones covered ≥ equity_threshold
    """

    def __init__(self):
        self.budget = BUDGET_INR
        self.grid_cap_kw = GRID_CAPACITY_MW * 1000

    def optimize_placement(self, buildings_df, budget: float = None) -> Dict:
        """Run LP optimization for solar placement."""
        budget = budget or self.budget
        
        df = buildings_df.copy()
        n = len(df)

        # Cost vector: installation cost per kW
        costs = df["installation_cost_inr"].values / np.maximum(df["capacity_kw"].values, 0.1)
        costs = np.clip(costs, PANEL_COST_PER_KW * 0.8, PANEL_COST_PER_KW * 1.3)

        # Max capacity at each site (kW) - rooftop constraint
        max_capacity = df["capacity_kw"].values

        # Energy yield per kW (kWh/kW/year)
        yield_per_kw = df["energy_kwh_year"].values / np.maximum(df["capacity_kw"].values, 0.1)

        # Solar score as priority weight
        solar_scores = df["solar_score"].values

        # Objective: minimize cost - weighted benefit
        # Benefit = yield * score (proxy for unmet demand satisfaction)
        benefit_weight = 0.3
        c = costs - benefit_weight * yield_per_kw * solar_scores

        # Inequality constraints: Ax ≤ b
        # 1. Budget constraint: Σ(cost_i × x_i) ≤ budget
        A_budget = costs.reshape(1, -1)
        b_budget = np.array([budget])

        # 2. Grid capacity: Σ(x_i) ≤ grid_cap_kw
        A_grid = np.ones((1, n))
        b_grid = np.array([self.grid_cap_kw])

        A_ub = np.vstack([A_budget, A_grid])
        b_ub = np.concatenate([b_budget, b_grid])

        # Bounds: 0 ≤ x_i ≤ max_capacity_i
        bounds = [(0, float(mc)) for mc in max_capacity]

        try:
            result = linprog(
                c, A_ub=A_ub, b_ub=b_ub, bounds=bounds,
                method="highs",
                options={"disp": False, "time_limit": 30}
            )
            
            if result.success:
                x_optimal = result.x
            else:
                # Fallback: greedy by ROI
                logger.warning("LP failed, using greedy fallback")
                x_optimal = self._greedy_allocation(df, budget)

        except Exception as e:
            logger.error(f"Optimization error: {e}")
            x_optimal = self._greedy_allocation(df, budget)

        # Post-process results
        return self._build_result(df, x_optimal, budget)

    def _greedy_allocation(self, df, budget: float) -> np.ndarray:
        """Greedy fallback: allocate by ROI score."""
        roi_score = df["annual_savings_inr"] / (df["installation_cost_inr"] + 1)
        sorted_idx = roi_score.argsort()[::-1]
        
        x = np.zeros(len(df))
        remaining_budget = budget
        
        for idx in sorted_idx:
            cost = df.iloc[idx]["installation_cost_inr"]
            if cost <= remaining_budget:
                x[idx] = df.iloc[idx]["capacity_kw"]
                remaining_budget -= cost
        return x

    def _build_result(self, df, x_optimal: np.ndarray, budget: float) -> Dict:
        """Build comprehensive optimization result."""
        installed_mask = x_optimal > 0.1
        n_installed = installed_mask.sum()
        
        total_cost = (x_optimal * df["installation_cost_inr"].values /
                      np.maximum(df["capacity_kw"].values, 0.1)).sum()
        total_capacity_kw = x_optimal.sum()
        total_energy_mwh_year = (
            x_optimal * df["energy_kwh_year"].values /
            np.maximum(df["capacity_kw"].values, 0.1)
        ).sum() / 1000
        total_co2_offset = (
            x_optimal * df["co2_offset_kg_year"].values /
            np.maximum(df["capacity_kw"].values, 0.1)
        ).sum()

        # Top 20 optimal sites
        df_result = df.copy()
        df_result["allocated_kw"] = x_optimal
        df_result["allocated_cost_inr"] = (
            x_optimal * df["installation_cost_inr"].values /
            np.maximum(df["capacity_kw"].values, 0.1)
        )
        
        top_sites = (df_result[installed_mask]
                     .nlargest(20, "allocated_kw")[
                         ["building_id", "lat", "lon", "building_type",
                          "rooftop_area_m2", "allocated_kw", "allocated_cost_inr",
                          "roi_years", "solar_score"]
                     ].to_dict("records"))

        # Zone-level equity check
        zones_covered = df_result[installed_mask]["building_type"].nunique()
        equity_score = min(1.0, zones_covered / 4)

        return {
            "optimization_status": "optimal",
            "budget_inr": budget,
            "budget_utilized_inr": round(total_cost, 0),
            "budget_utilization_pct": round(total_cost / budget * 100, 1),
            "sites_selected": int(n_installed),
            "total_capacity_kw": round(total_capacity_kw, 1),
            "total_capacity_mw": round(total_capacity_kw / 1000, 2),
            "total_energy_mwh_year": round(total_energy_mwh_year, 1),
            "total_co2_offset_tons_year": round(total_co2_offset / 1000, 0),
            "equity_score": round(equity_score, 2),
            "avg_roi_years": round(df_result[installed_mask]["roi_years"].mean(), 1),
            "annual_savings_inr": round(total_energy_mwh_year * 1000 * 8.0, 0),
            "top_sites": top_sites,
            "grid_capacity_utilized_pct": round(total_capacity_kw / self.grid_cap_kw * 100, 1),
        }

    def sensitivity_analysis(self, base_budget: float) -> List[Dict]:
        """Budget sensitivity: how does output scale with investment?"""
        multipliers = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]
        results = []
        for m in multipliers:
            budget = base_budget * m
            capacity_estimate = min(budget / PANEL_COST_PER_KW, GRID_CAPACITY_MW * 1000)
            energy_estimate = capacity_estimate * 5.65 * 365 * 0.185 * 0.80 / 1000
            results.append({
                "budget_cr": round(budget / 1e7, 1),
                "capacity_mw": round(capacity_estimate / 1000, 2),
                "energy_gwh_year": round(energy_estimate, 1),
                "sites": int(capacity_estimate / 15),
                "roi_years": round(PANEL_COST_PER_KW / (5.65 * 365 * 0.185 * 0.80 * 8), 1),
            })
        return results
