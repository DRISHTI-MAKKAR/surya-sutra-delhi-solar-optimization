-- Surya Sutra - PostGIS Database Schema
-- Team: Algoholics

CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS postgis_raster;

-- Buildings with rooftop solar potential
CREATE TABLE buildings (
    id              SERIAL PRIMARY KEY,
    building_id     VARCHAR(20) UNIQUE NOT NULL,
    geom            GEOMETRY(Point, 4326) NOT NULL,
    building_type   VARCHAR(50),
    rooftop_area_m2 NUMERIC(10,2),
    shadow_factor   NUMERIC(4,3),
    tilt_factor     NUMERIC(4,3),
    ghi_local       NUMERIC(6,3),           -- kWh/m²/day
    energy_kwh_year NUMERIC(12,2),
    capacity_kw     NUMERIC(8,2),
    install_cost_inr NUMERIC(14,2),
    co2_offset_kg   NUMERIC(12,2),
    roi_years       NUMERIC(5,1),
    solar_score     NUMERIC(5,3),
    zone_id         INTEGER,
    created_at      TIMESTAMP DEFAULT NOW()
);
CREATE INDEX idx_buildings_geom ON buildings USING GIST(geom);
CREATE INDEX idx_buildings_zone ON buildings(zone_id);
CREATE INDEX idx_buildings_type ON buildings(building_type);

-- Energy demand grid (population + commercial)
CREATE TABLE demand_grid (
    id                    SERIAL PRIMARY KEY,
    geom                  GEOMETRY(Point, 4326) NOT NULL,
    pop_density           NUMERIC(10,2),           -- persons/km²
    commercial_intensity  NUMERIC(5,3),
    residential_demand    NUMERIC(10,2),            -- kWh/day
    commercial_demand     NUMERIC(10,2),
    total_demand_kwh      NUMERIC(10,2),
    district_name         VARCHAR(100)
);
CREATE INDEX idx_demand_geom ON demand_grid USING GIST(geom);

-- Solar irradiance raster metadata
CREATE TABLE solar_irradiance (
    id              SERIAL PRIMARY KEY,
    district        VARCHAR(100),
    geom            GEOMETRY(Polygon, 4326),
    ghi_annual      NUMERIC(6,3),               -- kWh/m²/day
    ghi_jan         NUMERIC(6,3),
    ghi_feb         NUMERIC(6,3),
    ghi_mar         NUMERIC(6,3),
    ghi_apr         NUMERIC(6,3),
    ghi_may         NUMERIC(6,3),
    ghi_jun         NUMERIC(6,3),
    ghi_jul         NUMERIC(6,3),
    ghi_aug         NUMERIC(6,3),
    ghi_sep         NUMERIC(6,3),
    ghi_oct         NUMERIC(6,3),
    ghi_nov         NUMERIC(6,3),
    ghi_dec         NUMERIC(6,3),
    data_source     VARCHAR(100) DEFAULT 'NREL/Solargis'
);
CREATE INDEX idx_irradiance_geom ON solar_irradiance USING GIST(geom);

-- Energy zones (K-Means clusters)
CREATE TABLE energy_zones (
    id                      SERIAL PRIMARY KEY,
    zone_id                 INTEGER UNIQUE,
    label                   VARCHAR(100),
    geom                    GEOMETRY(Polygon, 4326),
    centroid_lat            NUMERIC(9,6),
    centroid_lon            NUMERIC(9,6),
    building_count          INTEGER,
    avg_solar_kwh_year      NUMERIC(12,2),
    total_potential_mwh     NUMERIC(12,2),
    commercial_ratio        NUMERIC(4,3),
    priority_score          INTEGER,
    recommended_capacity_kw NUMERIC(10,2)
);

-- Optimization results
CREATE TABLE optimization_runs (
    id                      SERIAL PRIMARY KEY,
    run_timestamp           TIMESTAMP DEFAULT NOW(),
    budget_inr              NUMERIC(16,2),
    budget_utilized_inr     NUMERIC(16,2),
    sites_selected          INTEGER,
    total_capacity_kw       NUMERIC(10,2),
    total_energy_mwh_year   NUMERIC(12,2),
    co2_offset_tons         NUMERIC(10,2),
    equity_score            NUMERIC(4,3),
    avg_roi_years           NUMERIC(5,1),
    algorithm               VARCHAR(50) DEFAULT 'HiGHS-LP'
);

-- Selected installation sites from optimization
CREATE TABLE optimal_sites (
    id                  SERIAL PRIMARY KEY,
    run_id              INTEGER REFERENCES optimization_runs(id),
    building_id         VARCHAR(20),
    geom                GEOMETRY(Point, 4326),
    allocated_kw        NUMERIC(8,2),
    allocated_cost_inr  NUMERIC(14,2),
    roi_years           NUMERIC(5,1),
    priority_rank       INTEGER
);
CREATE INDEX idx_optimal_sites_geom ON optimal_sites USING GIST(geom);
CREATE INDEX idx_optimal_sites_run ON optimal_sites(run_id);

-- Demand forecasts
CREATE TABLE demand_forecasts (
    id                  SERIAL PRIMARY KEY,
    forecast_year       INTEGER,
    total_demand_mw     NUMERIC(8,1),
    solar_supply_mw     NUMERIC(8,1),
    net_grid_demand_mw  NUMERIC(8,1),
    solar_share_pct     NUMERIC(5,1),
    confidence_lower    NUMERIC(8,1),
    confidence_upper    NUMERIC(8,1),
    model_version       VARCHAR(20) DEFAULT 'ARIMA-2.1.2',
    created_at          TIMESTAMP DEFAULT NOW()
);

-- Useful views
CREATE VIEW v_top_solar_sites AS
SELECT building_id, geom, building_type,
       rooftop_area_m2, energy_kwh_year, solar_score,
       roi_years, install_cost_inr
FROM buildings
WHERE solar_score > 0.80
ORDER BY energy_kwh_year DESC;

CREATE VIEW v_district_energy_balance AS
SELECT d.district_name,
       SUM(b.energy_kwh_year)/1e6 AS solar_potential_gwh,
       SUM(dg.total_demand_kwh)*365/1e6 AS demand_gwh,
       SUM(b.energy_kwh_year)/1e6 - SUM(dg.total_demand_kwh)*365/1e6 AS balance_gwh
FROM buildings b
JOIN demand_grid dg ON ST_DWithin(b.geom, dg.geom, 0.01)
JOIN (SELECT district_name, geom FROM demand_grid) d ON ST_DWithin(b.geom, d.geom, 0.05)
GROUP BY d.district_name;

COMMENT ON TABLE buildings IS 'Building footprints with computed solar potential. Source: OSM/Bhuvan';
COMMENT ON TABLE demand_grid IS 'Grid-based energy demand. Source: WorldPop + VIIRS';
COMMENT ON TABLE solar_irradiance IS 'GHI data. Source: NREL/Solargis/Mendeley';
COMMENT ON TABLE energy_zones IS 'KMeans clusters for energy planning zones';
