"""
api/solar_router.py - Solar potential endpoints
"""
from fastapi import APIRouter, Query
from core.solar_engine import engine
from typing import Optional

router = APIRouter()

@router.get("/buildings")
async def get_buildings(
    n: int = Query(500, description="Number of buildings to analyze"),
    building_type: Optional[str] = Query(None, description="Filter by type")
):
    df = engine.generate_synthetic_buildings(n)
    if building_type:
        df = df[df["building_type"] == building_type]
    return {
        "total": len(df),
        "buildings": df.drop(columns=["geometry"]).to_dict("records")
    }

@router.get("/heatmap")
async def get_heatmap(
    data_type: str = Query("solar", description="solar or demand"),
    n_points: int = Query(300, description="Number of data points")
):
    points = engine.get_heatmap_data(data_type, n_points)
    return {"type": data_type, "points": points, "count": len(points)}

@router.get("/calculate")
async def calculate_energy(
    area: float = Query(..., description="Rooftop area in m²"),
    shadow: float = Query(0.9, description="Shadow factor 0-1"),
    tilt: float = Query(0.95, description="Tilt factor 0-1"),
    efficiency: float = Query(0.185, description="Panel efficiency")
):
    return engine.calculate_energy_equation(area, shadow_factor=shadow, tilt_factor=tilt, efficiency=efficiency)

@router.get("/top-sites")
async def get_top_sites(limit: int = Query(20, description="Number of top sites")):
    df = engine.generate_synthetic_buildings(500)
    top = df.nlargest(limit, "energy_kwh_year")
    return {"sites": top.drop(columns=["geometry"]).to_dict("records")}
