"""api/optimize_router.py"""
from fastapi import APIRouter, Query
from core.solar_engine import engine
from core.optimizer import SolarOptimizer

router = APIRouter()
optimizer = SolarOptimizer()

@router.get("/placement")
async def optimize_placement(
    budget_cr: float = Query(50, description="Budget in Crore INR"),
    n_buildings: int = Query(500)
):
    df = engine.generate_synthetic_buildings(n_buildings)
    result = optimizer.optimize_placement(df, budget=budget_cr * 1e7)
    return result

@router.get("/sensitivity")
async def sensitivity_analysis(budget_cr: float = Query(50)):
    return {"sensitivity": optimizer.sensitivity_analysis(budget_cr * 1e7)}
